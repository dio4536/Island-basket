# Island Basket Jamaica — Roadmap
- [x] Phase 1: Storefront, categories, search, product pages, cart (sample data), policy/FAQ/contact pages
- [ ] Phase 2: Enable Lovable Cloud, schema + RLS, customer & admin sign-in — waiting on user go-ahead
- [ ] Phase 3: Checkout, delivery zones/slots, pickup, order creation with stock deduction, tracking, order history
- [ ] Phase 4: Admin dashboard (products, categories, inventory, orders, customers, delivery, promotions, reports, settings)
- [ ] Phase 5: Jamaican payment provider — blocked on merchant's chosen provider + credentials
- [ ] Phase 6: End-to-end testing and launch prep
