import { Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { formatJMD, imageFor, priceOf, type Product } from "@/lib/catalog";
import { useCart } from "@/lib/cart";

export function ProductCard({ product }: { product: Product }) {
  const { add, lines } = useCart();
  const inCart = lines.find((l) => l.slug === product.slug)?.qty ?? 0;
  const out = product.stock === 0;
  const maxed = inCart >= product.stock;
  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border bg-card shadow-card">
      <Link to="/product/$slug" params={{ slug: product.slug }} className="relative block aspect-square overflow-hidden bg-muted">
        <img src={imageFor(product)} alt={product.name} loading="lazy" width={816} height={816}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
        {product.salePrice && !out && (
          <span className="absolute left-3 top-3 rounded-full bg-accent px-2.5 py-1 text-xs font-bold text-accent-foreground">Special</span>
        )}
        {out && (
          <span className="absolute inset-0 grid place-items-center bg-background/70 text-sm font-semibold text-foreground">Out of stock</span>
        )}
      </Link>
      <div className="flex flex-1 flex-col gap-1 p-4">
        <Link to="/product/$slug" params={{ slug: product.slug }} className="line-clamp-2 font-semibold leading-snug hover:text-primary">
          {product.name}
        </Link>
        <p className="text-xs text-muted-foreground">per {product.unit}</p>
        <div className="mt-auto flex items-end justify-between gap-2 pt-3">
          <div className="min-w-0">
            <p className="font-display text-lg font-bold text-primary-deep">{formatJMD(priceOf(product))}</p>
            {product.salePrice && <p className="text-xs text-muted-foreground line-through">{formatJMD(product.price)}</p>}
          </div>
          <Button size="icon" aria-label={`Add ${product.name} to cart`} disabled={out || maxed}
            onClick={() => { add(product.slug); toast.success(`${product.name} added to cart`); }}
            className="shrink-0 rounded-full">
            <Plus />
          </Button>
        </div>
      </div>
    </div>
  );
}
