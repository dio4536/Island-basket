import { ProductCard } from "@/components/ProductCard";
import { filterProducts, type Sort } from "@/lib/catalog";

export function ProductBrowser({ title, subtitle, q, category, sort, onSort }: {
  title: string; subtitle?: string | undefined; q?: string | undefined; category?: string | undefined; sort: Sort; onSort: (s: Sort) => void;
}) {
  const list = filterProducts({ q, category, sort });
  return (
    <div className="mx-auto max-w-7xl px-4 pt-8">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div className="min-w-0">
          <h1 className="text-3xl font-extrabold text-primary-deep sm:text-4xl">{title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{subtitle ?? `${list.length} products`}</p>
        </div>
        <label className="flex items-center gap-2 text-sm">
          <span className="text-muted-foreground">Sort</span>
          <select value={sort} onChange={(e) => onSort(e.target.value as Sort)} className="rounded-full border bg-card px-3 py-2">
            <option value="popular">Most popular</option>
            <option value="price-asc">Price: low to high</option>
            <option value="price-desc">Price: high to low</option>
            <option value="newest">Newest</option>
          </select>
        </label>
      </div>
      {list.length === 0 ? (
        <div className="mt-10 rounded-2xl bg-muted p-10 text-center text-muted-foreground">No products found{q ? ` for “${q}”` : ""}.</div>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-5">
          {list.map((p) => <ProductCard key={p.slug} product={p} />)}
        </div>
      )}
    </div>
  );
}

export const parseSort = (s: unknown): Sort =>
  s === "price-asc" || s === "price-desc" || s === "newest" ? s : "popular";
