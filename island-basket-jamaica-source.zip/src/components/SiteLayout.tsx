import { Link, useNavigate } from "@tanstack/react-router";
import { MapPin, Search, ShoppingBasket } from "lucide-react";
import { useState, type ReactNode } from "react";
import { categories, store } from "@/lib/catalog";
import { useCart } from "@/lib/cart";

export function SiteLayout({ children }: { children: ReactNode }) {
  const { count } = useCart();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  return (
    <div className="flex min-h-screen flex-col">
      <div className="bg-primary-deep px-4 py-2 text-center text-xs font-medium text-primary-foreground">{store.announcement}</div>
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur">
        <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 md:grid-cols-[auto_minmax(0,1fr)_auto] md:gap-6">
          <Link to="/" className="flex min-w-0 items-center gap-2">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground">
              <ShoppingBasket className="h-5 w-5" />
            </span>
            <span className="truncate font-display text-lg font-bold text-primary-deep">Island Basket</span>
          </Link>
          <form role="search" className="col-span-2 row-start-2 md:col-span-1 md:row-start-auto"
            onSubmit={(e) => { e.preventDefault(); navigate({ to: "/shop", search: { q: q || undefined } }); }}>
            <label className="flex items-center gap-2 rounded-full border bg-muted px-4 py-2 focus-within:ring-2 focus-within:ring-ring">
              <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
              <span className="sr-only">Search groceries</span>
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search rice, plantain, ackee…"
                className="w-full min-w-0 bg-transparent text-sm outline-none" />
            </label>
          </form>
          <div className="flex items-center gap-2">
            <button type="button" className="hidden items-center gap-1 rounded-full px-3 py-2 text-sm text-muted-foreground hover:bg-muted lg:flex"
              title="Delivery areas will be set by the store">
              <MapPin className="h-4 w-4" /> Choose parish
            </button>
            <Link to="/cart" className="relative flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground" aria-label={`Cart, ${count} items`}>
              <ShoppingBasket className="h-4 w-4" />
              <span className="hidden sm:inline">Cart</span>
              <span className="grid h-5 min-w-5 place-items-center rounded-full bg-accent px-1 text-xs text-accent-foreground">{count}</span>
            </Link>
          </div>
        </div>
        <nav className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 pb-2 text-sm" aria-label="Categories">
          <Link to="/shop" className="shrink-0 rounded-full px-3 py-1.5 font-medium hover:bg-secondary" activeProps={{ className: "bg-secondary text-secondary-foreground" }}>Shop all</Link>
          {categories.slice(0, 9).map((c) => (
            <Link key={c.slug} to="/category/$slug" params={{ slug: c.slug }} className="shrink-0 rounded-full px-3 py-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
              activeProps={{ className: "bg-secondary text-secondary-foreground" }}>{c.name}</Link>
          ))}
        </nav>
      </header>
      <main className="flex-1">{children}</main>
      <footer className="mt-16 bg-primary-deep text-primary-foreground">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:grid-cols-2 md:grid-cols-4">
          <div>
            <p className="font-display text-xl font-bold">{store.name}</p>
            <p className="mt-2 text-sm opacity-80">Groceries and household essentials, ordered online for delivery or pickup.</p>
          </div>
          <div className="text-sm">
            <p className="mb-3 font-semibold">Shop</p>
            <ul className="space-y-2 opacity-80">
              <li><Link to="/shop">All products</Link></li>
              <li><Link to="/category/$slug" params={{ slug: "special-offers" }}>Weekly specials</Link></li>
              <li><Link to="/cart">Cart</Link></li>
            </ul>
          </div>
          <div className="text-sm">
            <p className="mb-3 font-semibold">Help</p>
            <ul className="space-y-2 opacity-80">
              <li><Link to="/contact">Contact us</Link></li>
              <li><Link to="/faq">FAQ</Link></li>
              <li><Link to="/policies/$slug" params={{ slug: "delivery" }}>Delivery & pickup</Link></li>
              <li><Link to="/policies/$slug" params={{ slug: "returns" }}>Returns & refunds</Link></li>
            </ul>
          </div>
          <div className="text-sm">
            <p className="mb-3 font-semibold">Legal</p>
            <ul className="space-y-2 opacity-80">
              <li><Link to="/policies/$slug" params={{ slug: "privacy" }}>Privacy policy</Link></li>
              <li><Link to="/policies/$slug" params={{ slug: "terms" }}>Terms of service</Link></li>
            </ul>
          </div>
        </div>
        <p className="border-t border-primary-foreground/15 px-4 py-4 text-center text-xs opacity-70">
          Prices in Jamaican dollars (JMD). Product listings shown are sample data.
        </p>
      </footer>
    </div>
  );
}
