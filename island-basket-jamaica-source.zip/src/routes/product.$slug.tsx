import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Minus, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { formatJMD, getCategory, getProduct, imageFor, priceOf } from "@/lib/catalog";
import { useCart } from "@/lib/cart";

export const Route = createFileRoute("/product/$slug")({
  loader: ({ params }) => {
    const product = getProduct(params.slug);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Product not found" }, { name: "robots", content: "noindex" }] };
    const t = `${loaderData.product.name} — Island Basket Jamaica`;
    return { meta: [{ title: t }, { name: "description", content: loaderData.product.description }, { property: "og:title", content: t }, { property: "og:description", content: loaderData.product.description }] };
  },
  notFoundComponent: () => <p className="p-16 text-center">Product not found.</p>,
  component: ProductPage,
});

function ProductPage() {
  const { product } = Route.useLoaderData();
  const { add, lines } = useCart();
  const inCart = lines.find((l) => l.slug === product.slug)?.qty ?? 0;
  const available = product.stock - inCart;
  const [qty, setQty] = useState(1);
  const cat = getCategory(product.category);
  const out = product.stock === 0;
  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 pt-8 md:grid-cols-2 md:gap-12">
      <img src={imageFor(product)} alt={product.name} width={816} height={816} className="aspect-square w-full rounded-3xl bg-muted object-cover" />
      <div className="min-w-0">
        {cat && <Link to="/category/$slug" params={{ slug: cat.slug }} className="text-sm font-semibold text-primary">{cat.name}</Link>}
        <h1 className="mt-2 text-3xl font-extrabold text-primary-deep sm:text-4xl">{product.name}</h1>
        <p className="mt-1 text-sm text-muted-foreground">SKU {product.sku} · sold per {product.unit}</p>
        <div className="mt-6 flex items-baseline gap-3">
          <span className="font-display text-3xl font-bold">{formatJMD(priceOf(product))}</span>
          {product.salePrice && <span className="text-muted-foreground line-through">{formatJMD(product.price)}</span>}
        </div>
        <p className={`mt-2 text-sm font-medium ${out ? "text-destructive" : product.stock <= 5 ? "text-accent-foreground" : "text-primary"}`}>
          {out ? "Out of stock" : product.stock <= 5 ? `Only ${product.stock} left` : "In stock"}
        </p>
        <p className="mt-6 text-muted-foreground">{product.description}</p>
        {!out && (
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <div className="flex items-center rounded-full border">
              <Button variant="ghost" size="icon" className="rounded-full" aria-label="Decrease" onClick={() => setQty((q) => Math.max(1, q - 1))}><Minus /></Button>
              <span className="w-10 text-center font-semibold" aria-live="polite">{qty}</span>
              <Button variant="ghost" size="icon" className="rounded-full" aria-label="Increase" disabled={qty >= available} onClick={() => setQty((q) => Math.min(available, q + 1))}><Plus /></Button>
            </div>
            <Button size="lg" className="rounded-full" disabled={available <= 0}
              onClick={() => { add(product.slug, qty); setQty(1); toast.success(`${product.name} added to cart`); }}>
              {available <= 0 ? "Max stock in cart" : "Add to cart"}
            </Button>
          </div>
        )}
        <p className="mt-8 rounded-xl bg-muted p-3 text-xs text-muted-foreground">Sample listing — not actual store inventory.</p>
      </div>
    </div>
  );
}
