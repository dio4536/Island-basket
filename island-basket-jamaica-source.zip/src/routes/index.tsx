import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Clock, MapPin, ShoppingCart, Truck } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ProductCard";
import { categories, filterProducts, products } from "@/lib/catalog";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Island Basket Jamaica — Groceries Delivered" },
      { name: "description", content: "Shop fresh produce, pantry staples and household essentials online in Jamaica. Prices in JMD." },
      { property: "og:title", content: "Island Basket Jamaica — Groceries Delivered" },
      { property: "og:description", content: "Shop fresh produce, pantry staples and household essentials online in Jamaica." },
    ],
  }),
  component: Home,
});

function Section({ title, to, children }: { title: string; to?: { slug: string }; children: React.ReactNode }) {
  return (
    <section className="mx-auto mt-14 max-w-7xl px-4">
      <div className="mb-5 flex items-end justify-between gap-4">
        <h2 className="text-2xl font-bold text-primary-deep sm:text-3xl">{title}</h2>
        {to ? (
          <Link to="/category/$slug" params={to} className="flex shrink-0 items-center gap-1 text-sm font-semibold text-primary">See all <ArrowRight className="h-4 w-4" /></Link>
        ) : (
          <Link to="/shop" className="flex shrink-0 items-center gap-1 text-sm font-semibold text-primary">See all <ArrowRight className="h-4 w-4" /></Link>
        )}
      </div>
      {children}
    </section>
  );
}

const Grid = ({ children }: { children: React.ReactNode }) => (
  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-5">{children}</div>
);

function Home() {
  const best = filterProducts({ sort: "popular" }).slice(0, 5);
  const specials = products.filter((p) => p.salePrice).slice(0, 5);
  const produce = products.filter((p) => p.category === "fruits-vegetables").slice(0, 5);
  const essentials = products.filter((p) => ["household-essentials", "cleaning-supplies", "personal-care", "rice-flour-grains"].includes(p.category)).slice(0, 5);
  return (
    <>
      <section className="mx-auto max-w-7xl px-4 pt-6">
        <div className="relative overflow-hidden rounded-3xl bg-primary-deep">
          <img src={hero} alt="Basket of Jamaican produce: ackee, plantain, mango and breadfruit" width={1600} height={1008}
            className="absolute inset-0 h-full w-full object-cover opacity-60" />
          <div className="absolute inset-0 bg-gradient-to-r from-primary-deep via-primary-deep/80 to-transparent" />
          <div className="relative max-w-xl px-6 py-16 text-primary-foreground sm:px-12 sm:py-24">
            <span className="inline-block rounded-full bg-accent px-3 py-1 text-xs font-bold text-accent-foreground">Online supermarket · Jamaica</span>
            <h1 className="mt-4 text-4xl font-extrabold leading-tight sm:text-6xl">Your grocery run, done from your phone.</h1>
            <p className="mt-4 text-lg opacity-90">Fresh produce, pantry staples and household essentials — delivered or ready for pickup.</p>
            <Button asChild size="lg" className="mt-8 rounded-full bg-accent text-accent-foreground hover:bg-accent/90">
              <Link to="/shop">Shop Groceries <ArrowRight /></Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto mt-12 max-w-7xl px-4">
        <h2 className="mb-5 text-2xl font-bold text-primary-deep sm:text-3xl">Shop by category</h2>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-8">
          {categories.map((c) => (
            <Link key={c.slug} to="/category/$slug" params={{ slug: c.slug }}
              className="group flex flex-col items-center gap-2 rounded-2xl bg-secondary p-3 text-center text-xs font-semibold text-secondary-foreground hover:bg-primary hover:text-primary-foreground sm:text-sm">
              <img src={c.image} alt="" loading="lazy" width={816} height={816} className="aspect-square w-full rounded-xl object-cover" />
              <span className="leading-tight">{c.name}</span>
            </Link>
          ))}
        </div>
      </section>

      <Section title="Best sellers"><Grid>{best.map((p) => <ProductCard key={p.slug} product={p} />)}</Grid></Section>
      <Section title="Weekly specials" to={{ slug: "special-offers" }}><Grid>{specials.map((p) => <ProductCard key={p.slug} product={p} />)}</Grid></Section>
      <Section title="Fresh produce" to={{ slug: "fruits-vegetables" }}><Grid>{produce.map((p) => <ProductCard key={p.slug} product={p} />)}</Grid></Section>
      <Section title="Everyday essentials"><Grid>{essentials.map((p) => <ProductCard key={p.slug} product={p} />)}</Grid></Section>

      <section className="mx-auto mt-16 max-w-7xl px-4">
        <div className="rounded-3xl bg-secondary p-8 sm:p-12">
          <h2 className="text-2xl font-bold text-primary-deep sm:text-3xl">How it works</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-4">
            {[
              [ShoppingCart, "Fill your basket", "Browse by category or search for what you need."],
              [MapPin, "Choose your area", "Pick delivery to your parish or collect at a pickup point."],
              [Clock, "Pick a time", "Select an available delivery or pickup time slot."],
              [Truck, "Receive your order", "We pack your groceries and track the order for you."],
            ].map(([Icon, t, d], i) => {
              const I = Icon as typeof Truck;
              return (
                <div key={i}>
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-primary text-primary-foreground"><I className="h-6 w-6" /></span>
                  <p className="mt-4 font-display text-lg font-bold">{t as string}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{d as string}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="mx-auto mt-10 max-w-7xl px-4">
        <div className="flex flex-col items-start justify-between gap-4 rounded-3xl border p-8 sm:flex-row sm:items-center">
          <div>
            <h2 className="text-xl font-bold text-primary-deep">Need help with an order?</h2>
            <p className="text-sm text-muted-foreground">Our support team can help with orders, delivery and payments.</p>
          </div>
          <Button asChild variant="outline" className="rounded-full"><Link to="/contact">Contact support</Link></Button>
        </div>
      </section>
    </>
  );
}
