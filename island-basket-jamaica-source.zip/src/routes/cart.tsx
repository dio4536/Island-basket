import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatJMD, getProduct, imageFor, priceOf } from "@/lib/catalog";
import { useCart } from "@/lib/cart";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Cart — Island Basket Jamaica" },
      { name: "description", content: "Review the groceries in your cart before checkout." },
      { property: "og:title", content: "Your Cart — Island Basket Jamaica" },
      { property: "og:description", content: "Review the groceries in your cart before checkout." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { lines, subtotal, setQty, remove } = useCart();
  const savings = lines.reduce((a, l) => {
    const p = getProduct(l.slug);
    return a + (p?.salePrice ? (p.price - p.salePrice) * l.qty : 0);
  }, 0);
  if (lines.length === 0)
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <h1 className="text-3xl font-extrabold text-primary-deep">Your cart is empty</h1>
        <p className="mt-2 text-muted-foreground">Add some groceries to get started.</p>
        <Button asChild className="mt-6 rounded-full"><Link to="/shop">Start shopping</Link></Button>
      </div>
    );
  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 pt-8 lg:grid-cols-[minmax(0,1fr)_360px]">
      <div className="min-w-0">
        <h1 className="text-3xl font-extrabold text-primary-deep">Your cart</h1>
        <ul className="mt-6 divide-y rounded-2xl border bg-card">
          {lines.map((l) => {
            const p = getProduct(l.slug)!;
            return (
              <li key={l.slug} className="grid grid-cols-[64px_minmax(0,1fr)_auto] items-center gap-4 p-4">
                <img src={imageFor(p)} alt="" loading="lazy" width={64} height={64} className="h-16 w-16 rounded-xl object-cover" />
                <div className="min-w-0">
                  <Link to="/product/$slug" params={{ slug: p.slug }} className="block truncate font-semibold">{p.name}</Link>
                  <p className="text-xs text-muted-foreground">{formatJMD(priceOf(p))} / {p.unit}</p>
                  <div className="mt-2 flex items-center gap-1">
                    <Button variant="outline" size="icon" className="h-7 w-7 rounded-full" aria-label="Decrease" onClick={() => setQty(p.slug, l.qty - 1)}><Minus /></Button>
                    <span className="w-8 text-center text-sm font-semibold">{l.qty}</span>
                    <Button variant="outline" size="icon" className="h-7 w-7 rounded-full" aria-label="Increase" disabled={l.qty >= p.stock} onClick={() => setQty(p.slug, l.qty + 1)}><Plus /></Button>
                    {l.qty >= p.stock && <span className="ml-2 text-xs text-muted-foreground">Max available</span>}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className="font-semibold">{formatJMD(priceOf(p) * l.qty)}</span>
                  <button onClick={() => remove(p.slug)} className="text-muted-foreground hover:text-destructive" aria-label={`Remove ${p.name}`}><Trash2 className="h-4 w-4" /></button>
                </div>
              </li>
            );
          })}
        </ul>
        <Link to="/shop" className="mt-4 inline-block text-sm font-semibold text-primary">← Continue shopping</Link>
      </div>
      <aside className="h-fit rounded-2xl bg-secondary p-6">
        <h2 className="text-xl font-bold">Order summary</h2>
        <dl className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatJMD(subtotal)}</dd></div>
          {savings > 0 && <div className="flex justify-between text-primary"><dt>Specials savings</dt><dd>−{formatJMD(savings)}</dd></div>}
          <div className="flex justify-between text-muted-foreground"><dt>Delivery</dt><dd>Calculated at checkout</dd></div>
          <div className="flex justify-between border-t pt-3 text-base font-bold"><dt>Estimated total</dt><dd>{formatJMD(subtotal)}</dd></div>
        </dl>
        <Button className="mt-6 w-full rounded-full" size="lg" disabled>Checkout — coming soon</Button>
        <p className="mt-3 text-xs text-muted-foreground">Checkout, delivery zones and payments are part of the next build phase. Final prices are confirmed by the store at checkout.</p>
      </aside>
    </div>
  );
}
