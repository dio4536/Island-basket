import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us — Island Basket Jamaica" },
      { name: "description", content: "Get help with orders, delivery and payments." },
      { property: "og:title", content: "Contact Us — Island Basket Jamaica" },
      { property: "og:description", content: "Get help with orders, delivery and payments." },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-2xl px-4 pt-12">
      <h1 className="text-4xl font-extrabold text-primary-deep">Contact us</h1>
      <p className="mt-4 text-muted-foreground">Questions about an order, delivery or payment? We're happy to help.</p>
      <div className="mt-8 rounded-2xl bg-secondary p-6 text-sm">
        <p className="font-semibold">Contact details coming soon</p>
        <p className="mt-1 text-muted-foreground">The store's phone, WhatsApp, email and opening hours will appear here once configured.</p>
      </div>
    </div>
  ),
});
