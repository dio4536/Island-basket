import { createFileRoute, notFound } from "@tanstack/react-router";

const policies: Record<string, { title: string; body: string[] }> = {
  delivery: { title: "Delivery & Pickup Policy", body: [
    "We deliver to service areas configured by the store. Fees, minimum order amounts and time slots depend on your parish and community and are shown before you order.",
    "If your address is outside our service area, you may choose pickup at an available location instead.",
  ] },
  returns: { title: "Returns & Refund Policy", body: [
    "If an item arrives damaged, incorrect or missing, contact us as soon as possible so we can review and resolve it.",
    "Approved refunds are returned using the original payment method or another agreed method.",
  ] },
  privacy: { title: "Privacy Policy", body: [
    "We collect only the information needed to fulfil your order, such as your name, phone number, address and order details.",
    "We do not store card numbers. Online payments are processed by the store's payment provider.",
  ] },
  terms: { title: "Terms of Service", body: [
    "Prices are in Jamaican dollars and may change. Final totals are confirmed at checkout.",
    "Product availability is limited to stock on hand. Orders may be adjusted or cancelled if items become unavailable.",
  ] },
};

export const Route = createFileRoute("/policies/$slug")({
  loader: ({ params }) => {
    const policy = policies[params.slug];
    if (!policy) throw notFound();
    return { policy };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Not found" }, { name: "robots", content: "noindex" }] };
    const t = `${loaderData.policy.title} — Island Basket Jamaica`;
    return { meta: [{ title: t }, { name: "description", content: loaderData.policy.body[0] }, { property: "og:title", content: t }, { property: "og:description", content: loaderData.policy.body[0] }] };
  },
  notFoundComponent: () => <p className="p-16 text-center">Page not found.</p>,
  component: Policy,
});

function Policy() {
  const { policy } = Route.useLoaderData();
  return (
    <article className="mx-auto max-w-2xl px-4 pt-12">
      <h1 className="text-4xl font-extrabold text-primary-deep">{policy.title}</h1>
      <p className="mt-2 text-xs text-muted-foreground">Draft wording — to be reviewed by the store before launch.</p>
      {policy.body.map((b) => <p key={b} className="mt-6 leading-relaxed text-muted-foreground">{b}</p>)}
    </article>
  );
}
