import { createFileRoute } from "@tanstack/react-router";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqs: [string, string][] = [
  ["Which areas do you deliver to?", "Delivery areas are set by the store by parish and community. If your area isn't served yet, pickup may be available."],
  ["How much is delivery?", "Delivery fees depend on your zone and are shown before you place your order."],
  ["How can I pay?", "Available payment methods will be shown at checkout. Options may include card, cash on delivery and bank transfer, depending on what the store enables."],
  ["What currency are prices in?", "All prices are in Jamaican dollars (JMD)."],
  ["Can I pick up my order instead?", "Yes, when pickup is enabled you can choose a pickup location and time at checkout."],
];

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Island Basket Jamaica" },
      { name: "description", content: "Answers about delivery, pickup, payments and orders." },
      { property: "og:title", content: "FAQ — Island Basket Jamaica" },
      { property: "og:description", content: "Answers about delivery, pickup, payments and orders." },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-2xl px-4 pt-12">
      <h1 className="text-4xl font-extrabold text-primary-deep">Frequently asked questions</h1>
      <Accordion type="single" collapsible className="mt-8">
        {faqs.map(([q, a]) => (
          <AccordionItem key={q} value={q}>
            <AccordionTrigger className="text-left">{q}</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">{a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  ),
});
