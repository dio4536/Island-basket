import { createFileRoute, notFound } from "@tanstack/react-router";
import { ProductBrowser, parseSort } from "@/components/ProductBrowser";
import type { Sort } from "@/lib/catalog";
import { getCategory } from "@/lib/catalog";

export const Route = createFileRoute("/category/$slug")({
  validateSearch: (s: { q?: unknown; sort?: unknown }): { sort?: Sort | undefined } => ({ sort: s.sort ? parseSort(s.sort) : undefined }),
  loader: ({ params }) => {
    const category = getCategory(params.slug);
    if (!category) throw notFound();
    return { category };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Category not found" }, { name: "robots", content: "noindex" }] };
    const t = `${loaderData.category.name} — Island Basket Jamaica`;
    const d = `Shop ${loaderData.category.name.toLowerCase()} online in Jamaica.`;
    return { meta: [{ title: t }, { name: "description", content: d }, { property: "og:title", content: t }, { property: "og:description", content: d }] };
  },
  notFoundComponent: () => <p className="p-16 text-center">Category not found.</p>,
  component: CategoryPage,
});

function CategoryPage() {
  const { category } = Route.useLoaderData();
  const { sort } = Route.useSearch();
  const navigate = Route.useNavigate();
  return <ProductBrowser title={category.name} category={category.slug} sort={sort ?? "popular"}
    onSort={(s) => navigate({ search: { sort: s } })} />;
}
