import { createFileRoute, Link } from "@tanstack/react-router";
import { ProductBrowser, parseSort } from "@/components/ProductBrowser";
import type { Sort } from "@/lib/catalog";
import { categories } from "@/lib/catalog";

export const Route = createFileRoute("/shop")({
  validateSearch: (s: { q?: unknown; sort?: unknown }): { q?: string | undefined; sort?: Sort | undefined } => ({
    q: typeof s.q === "string" && s.q ? s.q.slice(0, 80) : undefined,
    sort: s.sort ? parseSort(s.sort) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Shop All Groceries — Island Basket Jamaica" },
      { name: "description", content: "Browse and search all groceries and household products, priced in JMD." },
      { property: "og:title", content: "Shop All Groceries — Island Basket Jamaica" },
      { property: "og:description", content: "Browse and search all groceries and household products." },
    ],
  }),
  component: Shop,
});

function Shop() {
  const { q, sort } = Route.useSearch();
  const navigate = Route.useNavigate();
  return (
    <>
      <ProductBrowser title={q ? `Results for “${q}”` : "Shop all"} q={q} sort={sort ?? "popular"}
        onSort={(s) => navigate({ search: (p) => ({ ...p, sort: s }) })} />
      {!q && (
        <div className="mx-auto mt-10 flex max-w-7xl flex-wrap gap-2 px-4">
          {categories.map((c) => (
            <Link key={c.slug} to="/category/$slug" params={{ slug: c.slug }} className="rounded-full bg-secondary px-3 py-1.5 text-sm text-secondary-foreground hover:bg-primary hover:text-primary-foreground">{c.name}</Link>
          ))}
        </div>
      )}
    </>
  );
}
