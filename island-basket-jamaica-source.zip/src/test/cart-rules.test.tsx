import { describe, expect, it } from "vitest";
import { clampQty } from "@/lib/cart";
import { filterProducts, getProduct, type Product } from "@/lib/catalog";

describe("cart stock rules", () => {
  it("never allows more than available stock", () => {
    const p = getProduct("dish-sponges")!;
    expect(clampQty(p.slug, 99)).toBe(p.stock);
  });
  it("out-of-stock items cannot be added", () => {
    expect(clampQty("yellow-yam", 3)).toBe(0);
  });
});

describe("catalog", () => {
  it("sorts by price ascending", () => {
    const [a, b] = filterProducts({ sort: "price-asc" }) as [Product, Product];
    expect((a.salePrice ?? a.price) <= (b.salePrice ?? b.price)).toBe(true);
  });
  it("search matches product names", () => {
    expect(filterProducts({ q: "ackee" }).map((p) => p.slug)).toContain("ackee-can");
  });
});
