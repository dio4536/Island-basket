import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { getProduct, priceOf } from "./catalog";

type Line = { slug: string; qty: number };
type Ctx = {
  lines: Line[];
  count: number;
  subtotal: number;
  add: (slug: string, qty?: number) => void;
  setQty: (slug: string, qty: number) => void;
  remove: (slug: string) => void;
};
const CartCtx = createContext<Ctx | null>(null);
const KEY = "ib-cart";

export function clampQty(slug: string, qty: number) {
  const p = getProduct(slug);
  if (!p) return 0;
  return Math.max(0, Math.min(Math.floor(qty), p.stock));
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<Line[]>([]);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try {
      const raw = JSON.parse(localStorage.getItem(KEY) || "[]") as Line[];
      setLines(raw.map((l) => ({ ...l, qty: clampQty(l.slug, l.qty) })).filter((l) => l.qty > 0));
    } catch {}
    setReady(true);
  }, []);
  useEffect(() => {
    if (ready) localStorage.setItem(KEY, JSON.stringify(lines));
  }, [lines, ready]);

  const setQty = (slug: string, qty: number) =>
    setLines((ls) => {
      const q = clampQty(slug, qty);
      const rest = ls.filter((l) => l.slug !== slug);
      if (q === 0) return rest;
      const exists = ls.some((l) => l.slug === slug);
      return exists ? ls.map((l) => (l.slug === slug ? { ...l, qty: q } : l)) : [...ls, { slug, qty: q }];
    });
  const add = (slug: string, qty = 1) =>
    setQty(slug, (lines.find((l) => l.slug === slug)?.qty ?? 0) + qty);
  const remove = (slug: string) => setLines((ls) => ls.filter((l) => l.slug !== slug));
  const count = lines.reduce((a, l) => a + l.qty, 0);
  const subtotal = lines.reduce((a, l) => a + (getProduct(l.slug) ? priceOf(getProduct(l.slug)!) * l.qty : 0), 0);

  return <CartCtx.Provider value={{ lines, count, subtotal, add, setQty, remove }}>{children}</CartCtx.Provider>;
}

export function useCart() {
  const c = useContext(CartCtx);
  if (!c) throw new Error("useCart outside CartProvider");
  return c;
}
