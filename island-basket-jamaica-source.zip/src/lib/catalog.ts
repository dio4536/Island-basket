// SAMPLE DATA — placeholder catalog for Phase 1. Not real store inventory.
import produce from "@/assets/cat-produce.jpg";
import pantry from "@/assets/cat-pantry.jpg";
import household from "@/assets/cat-household.jpg";

export const store = {
  name: "Island Basket Jamaica",
  currency: "JMD",
  announcement: "Sample store preview — delivery areas and fees will be set by the store.",
};

export type Category = { slug: string; name: string; image: string };
export const categories: Category[] = ([
  ["fruits-vegetables", "Fruits & Vegetables", produce],
  ["meat-poultry", "Meat & Poultry", pantry],
  ["fish-seafood", "Fish & Seafood", pantry],
  ["rice-flour-grains", "Rice, Flour & Grains", pantry],
  ["canned-packaged", "Canned & Packaged", pantry],
  ["dairy-eggs", "Dairy & Eggs", pantry],
  ["bread-bakery", "Bread & Bakery", pantry],
  ["beverages-juices", "Beverages & Juices", pantry],
  ["snacks-confectionery", "Snacks & Confectionery", pantry],
  ["frozen-foods", "Frozen Foods", pantry],
  ["seasonings-cooking", "Seasonings & Cooking", pantry],
  ["personal-care", "Personal Care", household],
  ["cleaning-supplies", "Cleaning Supplies", household],
  ["household-essentials", "Household Essentials", household],
  ["baby-products", "Baby Products", household],
  ["special-offers", "Special Offers", produce],
] as [string, string, string][]).map(([slug, name, image]) => ({ slug, name, image }));

export type Product = {
  slug: string;
  sku: string;
  name: string;
  description: string;
  category: string;
  price: number;
  salePrice?: number;
  unit: string;
  stock: number;
  featured?: boolean;
  popularity: number;
  addedDays: number;
};

const p = (
  slug: string, name: string, category: string, price: number, unit: string, stock: number,
  extra: Partial<Product> = {},
): Product => ({
  slug, name, category, price, unit, stock,
  sku: "SMP-" + slug.slice(0, 6).toUpperCase(),
  description: `Sample listing for ${name.toLowerCase()}. Final details, pricing and availability will be set by the store.`,
  popularity: 50, addedDays: 30, ...extra,
});

export const products: Product[] = [
  p("ripe-plantain", "Ripe Plantain", "fruits-vegetables", 180, "each", 40, { featured: true, popularity: 95 }),
  p("julie-mango", "Julie Mango", "fruits-vegetables", 250, "lb", 25, { salePrice: 200, popularity: 88 }),
  p("callaloo-bundle", "Callaloo Bundle", "fruits-vegetables", 300, "bundle", 18, { featured: true, popularity: 80 }),
  p("scotch-bonnet", "Scotch Bonnet Peppers", "fruits-vegetables", 120, "pack", 60, { popularity: 92 }),
  p("yellow-yam", "Yellow Yam", "fruits-vegetables", 220, "lb", 0, { popularity: 70 }),
  p("sweet-potato", "Sweet Potato", "fruits-vegetables", 190, "lb", 30, { addedDays: 2 }),
  p("whole-chicken", "Whole Chicken", "meat-poultry", 450, "lb", 12, { featured: true, popularity: 90 }),
  p("chicken-wings", "Chicken Wings", "meat-poultry", 650, "kg", 8, { salePrice: 590 }),
  p("red-snapper", "Red Snapper", "fish-seafood", 1200, "lb", 6, { popularity: 75 }),
  p("saltfish", "Saltfish (Boneless)", "fish-seafood", 980, "pack", 20, { featured: true, popularity: 93 }),
  p("white-rice-5lb", "White Rice", "rice-flour-grains", 1100, "5 lb bag", 35, { popularity: 97 }),
  p("flour-4lb", "All-Purpose Flour", "rice-flour-grains", 650, "4 lb bag", 22),
  p("cornmeal", "Cornmeal", "rice-flour-grains", 420, "2 lb bag", 15, { addedDays: 3 }),
  p("ackee-can", "Canned Ackee", "canned-packaged", 1050, "can", 30, { featured: true, salePrice: 950, popularity: 94 }),
  p("red-peas-can", "Red Kidney Beans", "canned-packaged", 320, "can", 45),
  p("coconut-milk", "Coconut Milk", "canned-packaged", 280, "can", 3, { addedDays: 1 }),
  p("eggs-dozen", "Large Eggs", "dairy-eggs", 780, "dozen", 25, { popularity: 89 }),
  p("cheddar", "Cheddar Cheese", "dairy-eggs", 890, "pack", 10),
  p("hardo-bread", "Hardo Bread", "bread-bakery", 450, "loaf", 20, { popularity: 85 }),
  p("bulla-cake", "Bulla Cake", "bread-bakery", 160, "each", 50, { salePrice: 130 }),
  p("bottled-water", "Bottled Water 6-Pack", "beverages-juices", 600, "pack", 40),
  p("sorrel-drink", "Sorrel Drink", "beverages-juices", 380, "bottle", 14, { addedDays: 4 }),
  p("banana-chips", "Banana Chips", "snacks-confectionery", 220, "bag", 33),
  p("frozen-mixed-veg", "Mixed Vegetables", "frozen-foods", 520, "bag", 11),
  p("all-purpose-seasoning", "All-Purpose Seasoning", "seasonings-cooking", 350, "bottle", 26, { popularity: 82 }),
  p("vegetable-oil", "Vegetable Oil", "seasonings-cooking", 950, "bottle", 18, { salePrice: 850 }),
  p("bath-soap", "Bath Soap 3-Pack", "personal-care", 480, "pack", 30),
  p("toothpaste", "Toothpaste", "personal-care", 390, "tube", 20),
  p("laundry-detergent", "Laundry Detergent", "cleaning-supplies", 1450, "bottle", 9, { featured: true }),
  p("dish-sponges", "Dish Sponges", "cleaning-supplies", 260, "pack", 2),
  p("paper-towels", "Paper Towels", "household-essentials", 720, "2 rolls", 16),
  p("baby-wipes", "Baby Wipes", "baby-products", 640, "pack", 13),
];

export const priceOf = (x: Product) => x.salePrice ?? x.price;
export const formatJMD = (n: number) =>
  "J$" + n.toLocaleString("en-JM", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const getProduct = (slug: string) => products.find((x) => x.slug === slug);
export const getCategory = (slug: string) => categories.find((c) => c.slug === slug);
export const imageFor = (x: Product) => getCategory(x.category)?.image ?? pantry;
export const productsIn = (slug: string) =>
  slug === "special-offers" ? products.filter((x) => x.salePrice) : products.filter((x) => x.category === slug);

export type Sort = "popular" | "price-asc" | "price-desc" | "newest";
export function filterProducts(opts: { q?: string | undefined; category?: string | undefined; sort?: Sort | undefined }) {
  let list = opts.category ? productsIn(opts.category) : products.slice();
  const q = opts.q?.trim().toLowerCase();
  if (q) list = list.filter((x) => (x.name + " " + x.category).toLowerCase().includes(q));
  const s = opts.sort ?? "popular";
  list.sort((a, b) =>
    s === "price-asc" ? priceOf(a) - priceOf(b)
    : s === "price-desc" ? priceOf(b) - priceOf(a)
    : s === "newest" ? a.addedDays - b.addedDays
    : b.popularity - a.popularity,
  );
  return list;
}
